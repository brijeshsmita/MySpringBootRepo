/**
 * 
 */
package com.jpm.boot_user.exception;

/**
 * @author Smita B Kumar
 *
 */
public class MyUserException extends Exception {
	private static final long serialVersionUID = 1L;

	public MyUserException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyUserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
